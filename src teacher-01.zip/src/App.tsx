import './App.css'
import { TaskType, TodolistItem } from './TodolistItem'

// Create
// Read(view mode, sort, filter, search)
// Update
// Delete

// CRUD

// GUI, CLI, CUI




export const App = () => {
  // Data
  const todolistTitle: string = "What to learn"
  const todolistTasks: Array<TaskType> = [
    { id: 1, title: "HTML&CSS", isDone: true },
    { id: 2, title: "JS/TS", isDone: false },
    { id: 3, title: "REACT", isDone: false },
    { id: 4, title: "REDUX", isDone: false },
    { id: 5, title: "REST API", isDone: false },
  ]
  // UI
  return (
    <div className="app">
      <TodolistItem title={todolistTitle} tasks={todolistTasks} />
      {/* TodolistItem({
      title: "What to learn", 
      tasks:  [
              { id: 1, title: "HTML&CSS", isDone: true },
              { id: 2, title: "JS/TS", isDone: false },
              { id: 3, title: "REACT", isDone: false },
    ]
  }) */}
    </div>
  )
}


