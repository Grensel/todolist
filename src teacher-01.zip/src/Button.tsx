
type ButtonPropsType = {
    title: string
    onClickhandler?: ()=> void
}

export const Button = (props: ButtonPropsType) => {
    return (
        <button>{props.title}</button>
    )
}