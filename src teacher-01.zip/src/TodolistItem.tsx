import { Button } from "./Button"

type TodolistItemPropsType = {
    title: string
    tasks: Array<TaskType>
}

export type TaskType = {
    id: number
    title: string
    isDone: boolean
}


export const TodolistItem = (props: TodolistItemPropsType) => {

    const tasksList = (props.tasks.length === 0)
        ? <span>Your list is empty</span>
        : <ul>
            {
                props.tasks.map((task: TaskType) => {
                    return (
                        <li>
                            <input type="checkbox" checked={task.isDone} /> <span>{task.title}</span>
                        </li>
                    )
                })
            }
        </ul>

    // let tasksList = <span>Your list is empty</span>
    // if (props.tasks.length) {
    //     tasksList = <ul>
    //         {
    //             props.tasks.map((task: TaskType) => {
    //                 return (
    //                     <li>
    //                         <input type="checkbox" checked={task.isDone} /> <span>{task.title}</span>
    //                     </li>
    //                 )
    //             })
    //         }
    //     </ul>
    // }

    return (
        <div className="todolist">
            <h3>{props.title}</h3>
            <div>
                <input />
                <Button title="+" />
            </div>
            {tasksList}
            <div>
                <Button title="All" />
                <Button title="Active" />
                <Button title="Completed" />
            </div>
        </div>
    )
}